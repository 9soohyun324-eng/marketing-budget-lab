# 광고 예산 10억 원, 어디에 쓸까?

효율 기반 예산 재배분 제안 · 데이터로 문제해결하기 프로젝트 (Streamlit)

쇼핑몰 마케팅 팀장이 다음 분기 광고 예산을 **채널과 타깃에 어떻게 나눌지**를 데이터로 푸는 프로젝트입니다.

## 앱 구성

| 파일 | 내용 |
|---|---|
| `main.py` | 문제 소개, 핵심 지표, 채널별 ROAS 그래프, 이메일 포함 토글, 원본 미리보기 |
| `pages/1_데이터_살펴보기.py` | 채널·타깃·소재별 ROAS와 CAC 비교 (채널·타깃·기간 필터) |
| `pages/2_함정_찾기.py` | 이메일 제외 전후 비교, 소재별 CTR과 ROAS 비교 (제작 예정) |
| `pages/3_예산_시뮬레이터.py` | 채널별 예산 슬라이더, 비용 증가에 따른 ROAS 감소 반영 (제작 예정) |

## 실행 방법

```bash
pip install -r requirements.txt
streamlit run main.py
```

배포는 [Streamlit Community Cloud](https://streamlit.io/cloud)에서 이 저장소(Public)를 선택하고 Main file path를 `main.py`로 지정합니다.

## 폴더 구조

```
marketing-budget-lab/
├── main.py
├── requirements.txt
├── .gitignore
├── data/
│   ├── marketing_telemetry.csv   ← 앱이 읽는 메인 데이터 (반드시 필요)
│   └── (설명표 5개: channels, audiences, creative_formats, attribution_models, channel_profile)
└── pages/
```

## 분석 기준

- ROAS = 매출 합계 ÷ 비용 합계, CAC = 비용 합계 ÷ 주문 합계로 **합계에서 다시 계산**합니다.
- 원본의 `roas` 열은 비용이 1달러 미만인 277행에서 값이 어긋나서 쓰지 않습니다.
- `week` 열은 날짜와 맞지 않아 쓰지 않습니다.
- 이메일/CRM은 비용이 전체의 0.3%인데 ROAS가 약 589배라 평균을 왜곡하므로, 기본 화면에서는 제외하고 비교합니다.

## 데이터 출처와 한계

- 데이터: dianatofficial, *E-commerce Growth & Retail Media Benchmark 2026* (CC BY-SA 4.0)
- 기간: 2026-03-01 ~ 2026-09-26, 캠페인-일 10만 건
- **시뮬레이션으로 만든 가상 데이터**입니다. 실제 광고 성과가 아니므로 결과는 학습용 가설로만 해석해야 합니다.
- CC BY-SA 4.0에 따라 이 저장소의 데이터와 이를 바탕으로 만든 결과물도 같은 조건으로 공유합니다.
